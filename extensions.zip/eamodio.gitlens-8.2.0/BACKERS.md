<h1 align="center">Sponsors &amp; Backers</h1>

To my incredible backers &mdash; thank you so much for your contributions. I am truly humbled by your generosity and support. Please know that your support plays a important role in helping me realize GitLens' potential in making developer's lives easier.

If you'd like to join them in supporting GitLens, please consider:

- [Become a backer or sponsor on Patreon](https://www.patreon.com/eamodio)
- [One-time donation via PayPal](https://www.paypal.me/eamodio)

<h2 align="center">Gold Sponsors ($300+)</h2>
None yet &mdash; could be you!

<h2 align="center">Silver Sponsors ($150+)</h2>
None yet &mdash; could be you!


<h2 align="center">Bronse Sponsors ($50+)</h2>

- Michael Duffy

<h2 align="center">Generous Backers ($10+)</h2>

- TypeScript Types (Ken Howard)
- Borek Bernard
- Michael Scott-Nelson
- MrG0lden

<h2 align="center">Backers</h2>

- Guido Kessels
- Pavel Khlopin
- Eugen Grue
- Andreas Fertsch-Röver
- Nathaniel Blackburn
- Raphael Schweikert
- JehongAhn
